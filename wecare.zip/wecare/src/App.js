import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './css/style.css';
import NavBar from './components/layout/NavBar';
import FooterBar from './components/layout/FooterBar';
import Home from './components/home/Home';

function App() {
  return (
    <div className="App">
      <NavBar/>
      <Home/>
      <FooterBar/>
    </div>
  );
}

export default App;
