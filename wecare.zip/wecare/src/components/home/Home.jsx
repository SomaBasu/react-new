import React from 'react'
import coach from '../../images/coach.png'
import user from '../../images/woman.png'

function Home() {
  return (
    <section className='wc-section'>
        <div className="container">
            <div className="row section-title">
                <div className="col">
                    <h2 className='text-center'>We are at the heart of appropriate care</h2>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-md-4">                    
                    <div class="card card-column">
                        <img src={coach} class="card-img-top" alt="..." />
                        <div class="card-body d-flex flex-column gap-3">                            
                            <a href="#" class="btn btn-sky">Login as a Coach</a>
                            <a href="#" class="btn btn-sky">Join as a Coach</a>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">                    
                    <div class="card card-column">
                        <img src={user} class="card-img-top" alt="..." />
                        <div class="card-body d-flex flex-column gap-3">                            
                            <a href="#" class="btn btn-sky">Login as a User</a>
                            <a href="#" class="btn btn-sky">Join as a User</a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
  )
}

export default Home
